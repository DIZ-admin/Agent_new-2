# Agent User Manual

## 1. Introduction

Agent is an automated system designed to transfer photos between SharePoint libraries while enriching their metadata using artificial intelligence. This manual provides instructions for operating and maintaining the Agent system.

### 1.1 Purpose

The primary purpose of Agent is to:
- Automate the transfer of photos from a source SharePoint library to a destination library
- Extract and enhance photo metadata using AI analysis
- Ensure consistent naming and metadata application
- Verify successful transfers and provide reporting

### 1.2 Target Audience

This manual is intended for:
- System operators responsible for running the Agent system
- Data administrators managing photo libraries
- Content managers working with construction reference photos
- IT support personnel maintaining the system

## 2. Getting Started

### 2.1 System Requirements

To use Agent, you need:
- Computer with Python 3.8 or higher installed
- Internet connection with access to SharePoint
- SharePoint access credentials with appropriate permissions
- OpenAI API key with GPT-4 Vision access
- Sufficient disk space for photo processing

### 2.2 Installation

1. Obtain the Agent software package from your system administrator
2. Extract the package to a suitable directory (e.g., `C:\Projekts\Agent`)
3. Install required dependencies:
   ```
   pip install -r requirements.txt
   ```
4. Configure the system (see Section 3)
5. Verify installation by running a test process

### 2.3 Directory Structure

Familiarize yourself with the directory structure:
- `config/` - Configuration files
- `data/` - Data storage directories
- `docs/` - Documentation
- `logs/` - Log files
- `src/` - Source code
- `web/` - Web interface

## 3. Configuration

### 3.1 Basic Configuration

1. Navigate to the `config` directory
2. Edit the `config.env` file with appropriate settings:
   - SharePoint connection settings
   - Source and target library names
   - File settings
   - OpenAI API key

### 3.2 Metadata Schema Configuration

The system uses a schema file to understand the metadata structure of the target SharePoint library:

1. You can extract the schema automatically:
   ```
   python src/metadata_schema.py
   ```
2. Or manually configure the `sharepoint_choices.json` file

### 3.3 Custom Prompts

For optimal AI analysis results, customize the prompts in `config.env`:
- `OPENAI_PROMPT_ROLE` - Role instruction for AI
- `OPENAI_PROMPT_INSTRUCTIONS_PRE` - Instructions before schema
- `OPENAI_PROMPT_INSTRUCTIONS_POST` - Instructions after schema
- `OPENAI_PROMPT_EXAMPLE` - Example output format

## 4. Basic Operations

### 4.1 Running the Complete Process

To run the complete photo transfer and enrichment process:

```
python src/auto_process.py
```

This will execute all steps in sequence:
1. Extract metadata schema from SharePoint
2. Download photos and extract metadata
3. Analyze photos with OpenAI
4. Generate enriched metadata
5. Upload photos with metadata to SharePoint
6. Verify the transfer

### 4.2 Running Individual Steps

You can also run individual steps as needed:

```
python src/metadata_schema.py    # Extract metadata schema
python src/photo_metadata.py     # Download photos and extract metadata
python src/openai_analyzer.py    # Analyze photos with OpenAI
python src/metadata_generator.py # Generate enriched metadata
python src/sharepoint_uploader.py # Upload photos to SharePoint
python src/transfer_verification.py # Verify the transfer
```

### 4.3 Using the Web Interface

The system includes a web interface for monitoring and controlling the process:

1. Start the web interface:
   ```
   cd web
   npm run dev
   ```
2. Open the web interface in your browser at http://localhost:3000
3. Use the interface to monitor progress, view results, and configure settings

## 5. Advanced Operations

### 5.1 Batch Processing

For processing large numbers of photos:

1. Adjust batch settings in `config.env`:
   ```
   OPENAI_CONCURRENCY_LIMIT=5  # Number of concurrent API calls
   ```
2. Run the process with batch monitoring:
   ```
   python src/auto_process.py --monitor
   ```

### 5.2 Recovery from Errors

If the process encounters errors:

1. Check the log files in the `logs/` directory
2. Fix any configuration or permission issues
3. Run the specific step that failed, or continue from where the process stopped

### 5.3 Custom File Selection

To process only specific files:

1. Create a file list in JSON format
2. Use the custom selector mode:
   ```
   python src/photo_metadata.py --file-list=my_files.json
   ```

## 6. Monitoring and Maintenance

### 6.1 Log Files

The system generates several types of log files:

- **Process Logs**: Located in `logs/` directory
- **Error Logs**: Detailed error information
- **Transfer Reports**: Located in `data/reports/`

### 6.2 Regular Maintenance

Perform these maintenance tasks regularly:

1. **Clean up temporary files**:
   ```
   python src/utils/cleanup.py
   ```
2. **Update configuration** based on any SharePoint changes
3. **Check disk space** to ensure sufficient storage
4. **Review logs** for potential issues

### 6.3 Performance Monitoring

Monitor system performance:

1. Check processing times in log files
2. Monitor OpenAI API usage and costs
3. Adjust concurrency and batch settings if needed

## 7. Troubleshooting

### 7.1 Common Issues

#### Authentication Issues
- **Symptom**: Cannot connect to SharePoint
- **Solution**: Verify credentials and SharePoint URL

#### Photo Download Failures
- **Symptom**: Cannot download photos from source library
- **Solution**: Check permissions and library name

#### OpenAI API Errors
- **Symptom**: AI analysis fails
- **Solution**: Verify API key and check rate limits

#### Upload Failures
- **Symptom**: Cannot upload photos to target library
- **Solution**: Check permissions, file types, and size limits

### 7.2 Error Messages

Common error messages and their solutions:

| Error | Solution |
|-------|----------|
| "Authentication failed" | Check SharePoint credentials |
| "Library not found" | Verify library names |
| "API rate limit exceeded" | Reduce concurrency or wait |
| "Invalid metadata" | Check metadata schema |
| "File size exceeds limit" | Adjust MAX_FILE_SIZE or resize images |

### 7.3 Getting Support

If you encounter issues that you cannot resolve:

1. Collect relevant log files
2. Document the exact error and steps to reproduce
3. Contact your system administrator or IT support team

## 8. Reference Information

### 8.1 Command Line Arguments

The main scripts accept these command line arguments:

| Script | Argument | Description |
|--------|----------|-------------|
| auto_process.py | --monitor | Show real-time progress |
| photo_metadata.py | --file-list=FILE | Process specific files |
| openai_analyzer.py | --force | Force reanalysis of all photos |
| sharepoint_uploader.py | --dry-run | Simulate without uploading |
| transfer_verification.py | --detailed | Generate detailed report |

### 8.2 Configuration Parameters

Key configuration parameters:

| Parameter | Description |
|-----------|-------------|
| SHAREPOINT_SITE_URL | URL of the SharePoint site |
| SOURCE_LIBRARY_TITLE | Name of source library |
| SHAREPOINT_LIBRARY | Name of target library |
| TARGET_FILENAME_MASK | Format for renaming files |
| OPENAI_API_KEY | OpenAI API key |
| OPENAI_CONCURRENCY_LIMIT | Max concurrent API calls |

### 8.3 File Formats

Important file formats used by the system:

- **EXIF Metadata**: JSON format with camera and image information
- **OpenAI Analysis**: JSON format with AI-generated metadata
- **Enriched Metadata**: Combined JSON format for SharePoint
- **Transfer Reports**: CSV and HTML formats

## 9. Best Practices

### 9.1 Efficient Workflow

For optimal results:

1. Ensure source photos have consistent quality
2. Run schema extraction whenever SharePoint structure changes
3. Process photos in manageable batches
4. Schedule operations during off-peak hours
5. Regularly review and improve the AI prompts

### 9.2 Metadata Quality

To improve metadata quality:

1. Include sample photos with ideal metadata in the prompt example
2. Regularly review AI-generated metadata and refine prompts
3. Implement additional validation rules if needed
4. Consider manual review for critical images

### 9.3 Security Best Practices

To maintain system security:

1. Regularly update passwords
2. Use service accounts with minimal required permissions
3. Secure the configuration files
4. Protect OpenAI API keys

## 10. Glossary

| Term | Definition |
|------|------------|
| SharePoint | Microsoft's collaborative platform for document management |
| OpenAI | AI research laboratory providing GPT-4 Vision API |
| EXIF | Exchangeable Image File Format, metadata embedded in image files |
| Metadata | Structured information about photos (tags, descriptions, categories) |
| GPT-4 Vision | OpenAI's model capable of analyzing and describing image content |
| API | Application Programming Interface for software communication |
| Batch Processing | Processing multiple items in groups to improve efficiency |
| Source Library | The SharePoint library from which photos are downloaded |
| Target Library | The SharePoint library to which enriched photos are uploaded |
| Schema | The structure definition of metadata for the target SharePoint library |
