# Agent Configuration Management Guide

## 1. Overview

This document provides guidance on configuring and managing the Agent system, which automates the transfer of photos between SharePoint libraries with AI-powered metadata enrichment. Proper configuration is essential for the system to operate correctly and efficiently.

## 2. Configuration Files

### 2.1 Primary Configuration File

The main configuration file is located at `config/config.env`. This file contains environment variables that control the behavior of the Agent system.

#### 2.1.1 File Format

The configuration file uses the `.env` format, which consists of key-value pairs:

```
KEY=value
```

Comments can be added using the `#` character:

```
# This is a comment
KEY=value  # This is also a comment
```

#### 2.1.2 Required Configuration Groups

##### SharePoint Connection Settings
```
SHAREPOINT_SITE_URL=https://company.sharepoint.com/sites/your-site
SHAREPOINT_USERNAME=your.email@company.com
SHAREPOINT_PASSWORD=your-password
```

##### Library Settings
```
SOURCE_LIBRARY_TITLE=SourceLibrary
SHAREPOINT_LIBRARY=TargetLibrary
```

##### File Settings
```
METADATA_SCHEMA_FILE=sharepoint_choices.json
TARGET_FILENAME_MASK=Company_Referenzfoto_{number}
MAX_FILE_SIZE=15728640  # Maximum file size in bytes (15MB)
```

##### Connection Settings
```
MAX_CONNECTION_ATTEMPTS=3
CONNECTION_RETRY_DELAY=5
```

##### OpenAI Settings
```
OPENAI_API_KEY=your-openai-api-key
OPENAI_CONCURRENCY_LIMIT=5
MAX_TOKENS=1000
```

##### Logging Settings
```
LOG_LEVEL=INFO
LOG_FILE=sharepoint_connector.log
```

##### OpenAI Prompt Settings
```
OPENAI_PROMPT_ROLE="Agieren Sie als erfahrener Experte in der Herstellung und dem Bau von Holzhäusern und -konstruktionen."
OPENAI_PROMPT_INSTRUCTIONS_PRE="Analysieren Sie das folgende Bild..."
OPENAI_PROMPT_INSTRUCTIONS_POST="Stellen Sie sicher, dass der resultierende JSON-Code..."
OPENAI_PROMPT_EXAMPLE='Beispiel für das erwartete JSON-Format...'
```

### 2.2 Metadata Schema Configuration

The metadata schema configuration is stored in `config/sharepoint_choices.json`. This file defines the structure and constraints of the metadata fields in the target SharePoint library.

#### 2.2.1 File Format

The schema configuration uses JSON format with the following structure:

```json
{
  "library_title": "Library Name",
  "fields": [
    {
      "internal_name": "InternalFieldName",
      "title": "Display Name",
      "type": "FieldType",
      "required": true|false,
      "description": "Field description",
      "choices": ["Choice1", "Choice2", ...]  // Only for Choice/MultiChoice fields
    },
    ...
  ],
  "choice_fields": {
    "FieldName": {
      "title": "Display Name",
      "type": "FieldType",
      "choices": ["Choice1", "Choice2", ...]
    },
    ...
  }
}
```

## 3. Configuration Parameters

### 3.1 SharePoint Configuration

| Parameter | Description | Required | Default | Example |
|-----------|-------------|----------|---------|---------|
| SHAREPOINT_SITE_URL | URL of the SharePoint site | Yes | - | https://company.sharepoint.com/sites/your-site |
| SHAREPOINT_USERNAME | SharePoint username/email | Yes | - | user@company.com |
| SHAREPOINT_PASSWORD | SharePoint password | Yes | - | password123 |
| SOURCE_LIBRARY_TITLE | Title of the source library | Yes | - | SourceLibrary |
| SHAREPOINT_LIBRARY | Title of the target library | Yes | - | TargetLibrary |

### 3.2 File Management Configuration

| Parameter | Description | Required | Default | Example |
|-----------|-------------|----------|---------|---------|
| METADATA_SCHEMA_FILE | Name of the schema file | Yes | sharepoint_choices.json | sharepoint_choices.json |
| TARGET_FILENAME_MASK | Mask for renaming files | Yes | - | Company_Referenzfoto_{number} |
| MAX_FILE_SIZE | Maximum file size in bytes | No | 15728640 | 15728640 |

### 3.3 Connection Settings

| Parameter | Description | Required | Default | Example |
|-----------|-------------|----------|---------|---------|
| MAX_CONNECTION_ATTEMPTS | Maximum retry attempts for connections | No | 3 | 3 |
| CONNECTION_RETRY_DELAY | Delay between retry attempts in seconds | No | 5 | 5 |

### 3.4 OpenAI Configuration

| Parameter | Description | Required | Default | Example |
|-----------|-------------|----------|---------|---------|
| OPENAI_API_KEY | OpenAI API Key | Yes | - | sk-abcd1234... |
| OPENAI_CONCURRENCY_LIMIT | Maximum concurrent API calls | No | 5 | 5 |
| MAX_TOKENS | Maximum tokens for API response | No | 1000 | 1000 |

### 3.5 Logging Configuration

| Parameter | Description | Required | Default | Example |
|-----------|-------------|----------|---------|---------|
| LOG_LEVEL | Logging level | No | INFO | DEBUG |
| LOG_FILE | Log file name | No | sharepoint_connector.log | agent.log |

### 3.6 OpenAI Prompt Configuration

| Parameter | Description | Required | Default | Example |
|-----------|-------------|----------|---------|---------|
| OPENAI_PROMPT_ROLE | Role instruction for AI | Yes | - | "Act as an expert..." |
| OPENAI_PROMPT_INSTRUCTIONS_PRE | Instructions before schema | Yes | - | "Analyze the following..." |
| OPENAI_PROMPT_INSTRUCTIONS_POST | Instructions after schema | Yes | - | "Ensure the JSON code..." |
| OPENAI_PROMPT_EXAMPLE | Example of expected output | No | - | '{"Field": "Value"}' |

## 4. Configuration Management

### 4.1 Initial Configuration

1. Create a copy of `config.env.example` (if available) and rename it to `config.env`
2. Fill in all required parameters
3. Adjust optional parameters as needed
4. Validate the configuration (see Section 4.3)

### 4.2 Configuration Updates

1. Make a backup of the current configuration
2. Edit the configuration file
3. Validate the configuration
4. Test the system with the new configuration
5. Revert to the backup if issues occur

### 4.3 Configuration Validation

The Agent system validates the configuration at startup. You can manually validate the configuration by running:

```bash
python src/utils/config.py
```

This will check:
- Presence of required parameters
- Basic format validation
- File existence (where applicable)
- Connection tests (optional)

### 4.4 Schema Extraction

Instead of manually creating the schema file, you can extract it directly from SharePoint:

```bash
python src/metadata_schema.py
```

This will:
1. Connect to the target SharePoint library
2. Extract the metadata schema
3. Save it to the configured schema file

## 5. Security Considerations

### 5.1 Credential Management

The configuration file contains sensitive credentials:

- **SharePoint Credentials**: Username and password for SharePoint access
- **OpenAI API Key**: Key for accessing the OpenAI API

It is recommended to:

1. Restrict access to the configuration file
2. Use environment variables instead of hardcoded values in production
3. Consider using a secure credential store for production deployments

### 5.2 Permission Requirements

The system requires:

- Read permissions on the source SharePoint library
- Write permissions on the target SharePoint library
- Admin permissions if extracting schema information

## 6. Troubleshooting Configuration Issues

### 6.1 Common Issues

| Issue | Possible Cause | Solution |
|-------|----------------|----------|
| Authentication failure | Incorrect credentials | Verify username and password |
| Library not found | Incorrect library title | Verify library titles in SharePoint |
| Schema extraction fails | Insufficient permissions | Ensure appropriate SharePoint permissions |
| API rate limiting | Excessive concurrent requests | Reduce OPENAI_CONCURRENCY_LIMIT |
| Large file errors | Files exceed size limit | Adjust MAX_FILE_SIZE or pre-process photos |

### 6.2 Debugging Configuration

To debug configuration issues:

1. Set `LOG_LEVEL=DEBUG` in the configuration
2. Run the component with issues
3. Check the log file for detailed error messages
4. Adjust configuration based on error messages

## 7. Advanced Configuration

### 7.1 Custom Prompt Engineering

The AI analysis quality depends significantly on the prompt. To optimize results:

1. Review the current prompt in the configuration
2. Adjust language and instructions based on your specific needs
3. Update the example to match your desired output format
4. Test with a small set of photos before full deployment

### 7.2 Performance Tuning

To optimize performance:

1. Adjust `OPENAI_CONCURRENCY_LIMIT` based on your API quota
2. Balance between processing speed and API costs
3. Consider batch sizes for processing large photo collections
4. Monitor and adjust based on observed performance

### 7.3 Error Handling Configuration

To customize error handling:

1. Adjust `MAX_CONNECTION_ATTEMPTS` based on network reliability
2. Set appropriate `CONNECTION_RETRY_DELAY` for your environment
3. Consider implementing custom error handlers for specific scenarios

## 8. Configuration Templates

### 8.1 Minimal Configuration Template

```
# Minimal configuration
SHAREPOINT_SITE_URL=https://company.sharepoint.com/sites/your-site
SHAREPOINT_USERNAME=user@company.com
SHAREPOINT_PASSWORD=password
SOURCE_LIBRARY_TITLE=SourceLibrary
SHAREPOINT_LIBRARY=TargetLibrary
METADATA_SCHEMA_FILE=sharepoint_choices.json
TARGET_FILENAME_MASK=Company_Photo_{number}
OPENAI_API_KEY=your-openai-key
```

### 8.2 Production Configuration Template

```
# Production configuration
SHAREPOINT_SITE_URL=https://company.sharepoint.com/sites/production
SHAREPOINT_USERNAME=service-account@company.com
SHAREPOINT_PASSWORD=secure-password
SOURCE_LIBRARY_TITLE=ProductionSourceLibrary
SHAREPOINT_LIBRARY=ProductionTargetLibrary
METADATA_SCHEMA_FILE=production_schema.json
TARGET_FILENAME_MASK=Company_Official_{number}
MAX_FILE_SIZE=20971520
MAX_CONNECTION_ATTEMPTS=5
CONNECTION_RETRY_DELAY=10
OPENAI_API_KEY=production-key
OPENAI_CONCURRENCY_LIMIT=10
MAX_TOKENS=1500
LOG_LEVEL=INFO
LOG_FILE=production_agent.log
# Custom prompts for production...
```

## 9. Version Control for Configuration

Consider implementing version control for configuration:

1. Store configuration templates in version control
2. Exclude actual configuration with credentials from version control
3. Document configuration changes with each system update
4. Implement a configuration backup and restore procedure

## 10. References

- Python dotenv documentation: [python-dotenv on PyPI](https://pypi.org/project/python-dotenv/)
- SharePoint API documentation: [SharePoint REST API](https://docs.microsoft.com/en-us/sharepoint/dev/sp-add-ins/get-to-know-the-sharepoint-rest-service)
- OpenAI API documentation: [OpenAI API](https://platform.openai.com/docs/api-reference)
