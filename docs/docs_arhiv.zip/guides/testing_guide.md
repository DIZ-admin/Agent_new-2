# Agent Testing Guide

## 1. Introduction

This document outlines the testing procedures for the Agent system, which automates the transfer of photos between SharePoint libraries with AI-enhanced metadata. Proper testing ensures the system functions correctly and reliably in various scenarios.

### 1.1 Purpose

The purpose of this testing guide is to:
- Ensure all components of the Agent system function as expected
- Verify system behavior under various conditions
- Identify and resolve potential issues before production use
- Validate that the system meets the specified requirements

### 1.2 Scope

This testing guide covers:
- Unit testing of individual components
- Integration testing of component interactions
- System testing of the end-to-end process
- Performance testing under various loads
- Error handling and recovery testing

## 2. Test Environment Setup

### 2.1 Prerequisites

To set up the test environment, you need:
- Development machine with Python 3.8 or higher
- Test SharePoint site with source and target libraries
- Test photos with various characteristics
- OpenAI API key with sufficient credits for testing

### 2.2 Test Environment Configuration

1. Create a test configuration file:
   ```
   cp config/config.env config/config.test.env
   ```

2. Edit the test configuration with test-specific settings:
   ```
   SHAREPOINT_SITE_URL=https://company.sharepoint.com/sites/test
   SOURCE_LIBRARY_TITLE=TestSourceLibrary
   SHAREPOINT_LIBRARY=TestTargetLibrary
   ```

3. Create test directories:
   ```
   mkdir -p test_data/{downloads,metadata,analysis,upload,uploaded,reports}
   ```

### 2.3 Test Data Preparation

Prepare a variety of test photos:
- Different sizes (small, medium, large)
- Different types (JPEG, PNG, TIFF)
- Different content (interiors, exteriors, details)
- With and without EXIF metadata
- Some with potential processing challenges

## 3. Unit Testing

### 3.1 Unit Test Framework

The Agent system uses pytest for unit testing:
```
pytest src/tests/
```

### 3.2 Key Unit Test Areas

#### 3.2.1 SharePoint Authentication
- Test successful authentication
- Test authentication failure handling
- Test reconnection logic

#### 3.2.2 Metadata Extraction
- Test EXIF extraction from various file types
- Test handling of missing EXIF data
- Test metadata format validation

#### 3.2.3 OpenAI Integration
- Test API connection
- Test prompt formatting
- Test response parsing
- Test error handling

#### 3.2.4 File Operations
- Test file reading/writing
- Test file renaming
- Test directory operations

### 3.3 Running Unit Tests

Run specific test categories:
```
pytest src/tests/test_sharepoint.py
pytest src/tests/test_metadata.py
pytest src/tests/test_openai.py
pytest src/tests/test_files.py
```

## 4. Integration Testing

### 4.1 Component Integration Tests

Test the integration between components:

#### 4.1.1 SharePoint and Metadata Extraction
- Test downloading photos and extracting metadata

#### 4.1.2 OpenAI Analysis and Metadata Generation
- Test sending photos to OpenAI and processing results

#### 4.1.3 Metadata Generation and SharePoint Upload
- Test applying generated metadata during upload

### 4.2 Running Integration Tests

```
pytest src/tests/integration/
```

## 5. System Testing

### 5.1 End-to-End Process Testing

Test the complete workflow from source to target:

1. Configure the test environment
2. Run the end-to-end process:
   ```
   python src/auto_process.py --test
   ```
3. Verify results in the target library

### 5.2 Test Scenarios

#### 5.2.1 Basic Scenario
- Small number of standard photos
- All operations should succeed

#### 5.2.2 Large Volume Scenario
- Large number of photos (50+)
- Tests batch processing and performance

#### 5.2.3 Edge Case Scenario
- Unusual photos (very large, unusual formats)
- Tests system robustness

### 5.3 Verification Checklist

For each test scenario, verify:
- All photos are transferred correctly
- Metadata is correctly applied
- Naming convention is followed
- Reports are generated accurately

## 6. Performance Testing

### 6.1 Load Testing

Test the system under various loads:

#### 6.1.1 Concurrent API Calls
- Test with different OPENAI_CONCURRENCY_LIMIT values
- Measure throughput and reliability

#### 6.1.2 Large Photo Collections
- Test with increasing numbers of photos
- Measure memory usage and processing times

### 6.2 Resource Utilization

Monitor system resources during testing:
- CPU usage
- Memory consumption
- Disk I/O
- Network bandwidth

### 6.3 Optimization

Based on performance testing:
- Adjust batch sizes
- Optimize API concurrency
- Tune error retry parameters

## 7. Error Handling and Recovery Testing

### 7.1 Induced Failure Testing

Intentionally introduce failures to test recovery:

#### 7.1.1 Network Failures
- Disconnect network during operations
- Verify retry and recovery behavior

#### 7.1.2 API Errors
- Simulate API rate limiting
- Test with invalid API responses

#### 7.1.3 File System Errors
- Test with read-only directories
- Test with disk full scenarios

### 7.2 Recovery Testing

Verify the system can recover from interruptions:
1. Start the process
2. Force termination mid-process
3. Restart and verify continuation

## 8. Security Testing

### 8.1 Authentication Security

- Verify secure handling of credentials
- Test with invalid credentials
- Test permission boundaries

### 8.2 Data Protection

- Verify data is not exposed in logs
- Check temporary file cleanup
- Verify secure API communication

## 9. Regression Testing

### 9.1 Regression Test Suite

Maintain a suite of tests for ensuring changes don't break existing functionality:

```
pytest src/tests/regression/
```

### 9.2 Automated Testing

Set up automated testing:
- Run tests on code changes
- Schedule regular regression testing
- Maintain test coverage metrics

## 10. Test Documentation

### 10.1 Test Reports

Generate and maintain test reports:
- Test results summary
- Issues identified
- Performance metrics
- Recommendations

### 10.2 Test Cases Database

Maintain a database of test cases:
- Test ID
- Description
- Preconditions
- Steps
- Expected results
- Actual results
- Status

## 11. Troubleshooting During Testing

### 11.1 Common Test Issues

| Issue | Potential Cause | Resolution |
|-------|----------------|------------|
| Authentication failures | Incorrect test credentials | Update test configuration |
| Permission errors | Insufficient test account permissions | Adjust permissions or use different account |
| API rate limiting | Too many concurrent test calls | Reduce concurrency in test configuration |
| Timeout errors | Network latency or service unavailability | Increase timeout settings for tests |
| Inconsistent results | Race conditions or timing issues | Add delays or synchronization in tests |

### 11.2 Debugging Tests

For difficult-to-diagnose issues:
1. Enable verbose logging:
   ```
   pytest -v --log-cli-level=DEBUG src/tests/problem_test.py
   ```
2. Use the debug flag with auto_process:
   ```
   python src/auto_process.py --test --debug
   ```

## 12. Continuous Improvement

### 12.1 Test Coverage Analysis

Regularly analyze test coverage:
```
pytest --cov=src src/tests/
```

### 12.2 Test Suite Maintenance

- Add tests for new features
- Update tests when requirements change
- Remove obsolete tests
- Improve test performance

### 12.3 Automation Opportunities

Identify opportunities to automate testing:
- Integration with CI/CD pipelines
- Scheduled regression testing
- Automated performance benchmarking

## Appendix A: Test Data Sets

### A.1 Standard Test Set
- 10 JPEG photos with complete EXIF data
- Various wooden construction subjects
- Mix of interior and exterior shots

### A.2 Edge Case Test Set
- Very large photos (>10MB)
- Photos without EXIF data
- Non-standard image formats
- Photos with unusual aspect ratios

### A.3 Performance Test Set
- 100+ photos for volume testing
- Variety of sizes and types
- Organized in subfolders

## Appendix B: Test Scripts

### B.1 Setup Test Environment

```python
#!/usr/bin/env python3
"""Set up test environment for Agent testing."""

import os
import shutil
from pathlib import Path

# Create test directories
test_dirs = [
    'test_data/downloads',
    'test_data/metadata',
    'test_data/analysis',
    'test_data/upload',
    'test_data/uploaded',
    'test_data/reports'
]

for dir_path in test_dirs:
    Path(dir_path).mkdir(parents=True, exist_ok=True)
    print(f"Created directory: {dir_path}")

# Copy test configuration
shutil.copy('config/config.env', 'config/config.test.env')
print("Created test configuration file")

print("Test environment setup complete")
```

### B.2 Run All Tests

```python
#!/usr/bin/env python3
"""Run complete test suite for Agent system."""

import subprocess
import sys
import time

def run_command(command):
    """Run a command and return exit code."""
    print(f"Running: {command}")
    result = subprocess.run(command, shell=True)
    return result.returncode

# Run unit tests
unit_tests = run_command("pytest src/tests/")
if unit_tests != 0:
    print("Unit tests failed")
    sys.exit(1)

# Run integration tests
integration_tests = run_command("pytest src/tests/integration/")
if integration_tests != 0:
    print("Integration tests failed")
    sys.exit(1)

# Run end-to-end test
e2e_test = run_command("python src/auto_process.py --test")
if e2e_test != 0:
    print("End-to-end test failed")
    sys.exit(1)

print("All tests passed successfully")
```
