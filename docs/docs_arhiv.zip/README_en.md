# Agent

## Overview

Agent is an automated system for transferring photos between SharePoint libraries while enriching their metadata using artificial intelligence. The project is designed to streamline and automate the workflow for managing reference photos, particularly focusing on construction and architectural photography.

## Features

- **Automated Transfer**: Moves photos from a source SharePoint library to a destination library
- **Metadata Extraction**: Extracts EXIF data and other metadata from photos
- **AI-Powered Analysis**: Uses OpenAI's GPT-4 Vision to analyze photos and generate relevant metadata
- **Metadata Enrichment**: Combines EXIF data with AI analysis to create comprehensive metadata
- **SharePoint Integration**: Uploads photos with enhanced metadata to the target SharePoint library
- **Verification**: Validates successful transfers and generates reports

## Requirements

- Python 3.8 or higher
- SharePoint access with appropriate permissions
- OpenAI API key with GPT-4 Vision access

## Installation

1. Clone this repository:

```bash
git clone https://github.com/erni/agent.git
cd agent
```

2. Install dependencies:

```bash
pip install -r requirements.txt
```

3. Configure the application by editing `config/config.env`:

```ini
# SharePoint connection settings
SHAREPOINT_SITE_URL=https://your-company.sharepoint.com/sites/your-site
SHAREPOINT_USERNAME=your.email@your-company.com
SHAREPOINT_PASSWORD=your-password

# Library settings
SOURCE_LIBRARY_TITLE=SourceLibrary
SHAREPOINT_LIBRARY=TargetLibrary

# File settings
METADATA_SCHEMA_FILE=sharepoint_choices.json
TARGET_FILENAME_MASK=Company_Referenzfoto_{number}
MAX_FILE_SIZE=15728640

# OpenAI settings
OPENAI_API_KEY=your-openai-api-key
OPENAI_CONCURRENCY_LIMIT=5
MAX_TOKENS=1000
```

## Usage

### Automatic Processing

To run the complete process automatically:

```bash
python src/auto_process.py
```

This will execute all steps in sequence:
1. Extract metadata schema from SharePoint
2. Download photos and extract metadata
3. Analyze photos with OpenAI
4. Generate enriched metadata
5. Upload photos with metadata to SharePoint
6. Verify the transfer

### Individual Steps

You can also run each step individually:

```bash
python src/metadata_schema.py    # Extract metadata schema
python src/photo_metadata.py     # Download photos and extract metadata
python src/openai_analyzer.py    # Analyze photos with OpenAI
python src/metadata_generator.py # Generate enriched metadata
python src/sharepoint_uploader.py # Upload photos to SharePoint
python src/transfer_verification.py # Verify the transfer
```

## Project Structure

```
/
├── config/                  # Configuration files
│   ├── config.env           # Environment variables
│   └── sharepoint_choices.json  # SharePoint metadata schema
├── data/                    # Data storage
│   ├── downloads/           # Downloaded photos
│   ├── metadata/            # Extracted metadata
│   ├── analysis/            # OpenAI analysis results
│   ├── upload/              # Files prepared for upload
│   ├── uploaded/            # Successfully uploaded files
│   └── reports/             # Transfer reports
├── docs/                    # Documentation
├── logs/                    # Log files
├── src/                     # Python source code
│   ├── utils/               # Utility modules
│   │   ├── config.py        # Configuration management
│   │   ├── logging.py       # Logging utilities
│   │   ├── paths.py         # Path management
│   │   └── api.py           # API integration utilities
│   ├── auto_process.py      # Orchestration script
│   ├── metadata_generator.py # Metadata generation
│   ├── metadata_schema.py   # Schema analyzer
│   ├── openai_analyzer.py   # AI photo analysis
│   ├── photo_metadata.py    # Photo metadata extraction
│   ├── sharepoint_auth.py   # SharePoint authentication
│   ├── sharepoint_uploader.py # SharePoint upload
│   └── transfer_verification.py # Verification
└── web/                     # Web interface (Next.js/React)
```

## Testing

Run the tests:

```bash
pytest src/tests
```

## License

Proprietary - All rights reserved.

## Acknowledgments

- ERNI for project support
- OpenAI for providing the GPT-4 Vision API
- Microsoft for SharePoint API access
